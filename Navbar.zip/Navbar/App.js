import './App.css';
import {BrowserRouter as Router,Route, Routes} from 'react-router-dom'
import Home from './components/pages/Home';
import Navbar from './components/Navbar/Navbar';
import Projects from './components/pages/Projects';
import Services from './components/pages/Services';
import Contact from './components/pages/Contact';

const App=()=> {
  return (
    <Router>
      <Navbar/>
      <Routes>
        <Route path='/' component= {Home} exact>
          <Home/>
        </Route>
        <Route path='/projects' component= {Projects} exact>
          <Projects/>
        </Route>
        <Route path='/services' component= {Services} exact>
          <Services/>
        </Route>
        <Route path='/contact' component= {Contact} exact>
          <Contact/>
        </Route>
      </Routes>
    </Router>
  );
}

export default App;