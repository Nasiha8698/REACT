import './App.css';
import EmpCrud from './components/EmpCrud';
import CreateEmployee from './components/CreateEmployee';

function App() {
  return (
    <div className="App">
      <EmpCrud/>
      <CreateEmployee/>
    
    </div>

  );
}

export default App;