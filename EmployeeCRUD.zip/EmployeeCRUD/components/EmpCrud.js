import React from 'react'

 function EmpCrud() {
  return (
    <div>
        <table>
        <tr>
          <th>Name</th>
          <th>Job</th>
          <th>Remove</th>
          </tr>
        </table>

    </div>
  )
}

export default EmpCrud